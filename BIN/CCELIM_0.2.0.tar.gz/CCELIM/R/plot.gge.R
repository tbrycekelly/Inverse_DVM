plot.gge = function(image.dir, hash, l, w) {
    tempname = paste(image.dir, "GGE_", hash, ".png", sep='')
    #pdf(tempname, height=640, width=1200)
    #pdf(tempname)
    png(tempname)
    par(mar=c(8,6,6,5))
    plot(x=c(1:length(w)), y=NULL,
         cex.lab=1.8, ylim=c(0,0.5), 
         col="red",yaxt='n', xaxt="n", 
         xlab="", ylab="GGE ± SD", 
         main=paste("Gross Growth Efficiencies"),
         xlim=c(0.5, length(w)+0.5)
    )
    load(paste('./data/Model-', l[1], '.RData', sep=''))
    
    GGElab = c("Hnf", "Mic", "Smz", "Lmz", "Deep Hnf", "Deep Mic", "Gel", "Bac", "Deep Bac", "vmSMZ", "vmLMZ", "dSMZ", "dLMZ")
    Gmin = c( .1,          # HNF
              .1,          # MIC
              .1,          # SMZ
              .1,          # LMZ
              .1,          # dHNF
              .1,          # dMIC
              .1,          # GEL
              .05,          # BAC
              .05,          # dBAC
              .1,          # vmSMZ
              .1,          # vmLMZ
              .1,          # dSMZ
              .1          # dLMZ
    )
    
    Gmax = c( .4,          # HNF
              .4,          # MIC
              1+as.numeric(model$G[95,50]),          # SMZ
              1+as.numeric(model$G[97,113]),          # LMZ
              .4,          # dHNF
              .4,          # dMIC
              .4,          # GEL
              .3,          # BAC
              .3,          # dBAC
              1+as.numeric(model$G[99,106]),          # vmSMZ
              1+as.numeric(model$G[103,137]),          # vmLMZ
              1+as.numeric(model$G[101,64]),          # dSMZ
              1+as.numeric(model$G[105,69])           # dLMZ
    )
    axis(side=1, labels=GGElab[w], cex.axis=1.8 ,at=c(1:length(w)), las=2)
    axis(side=2, at=c(0.1,0.2, 0.3, 0.4, 0.5), cex.axis=2)
    rect(1:length(w)-.42, Gmin[w], 1:length(w)+.42, Gmax[w], density=5, col="white", border="black", lty=4)
    
    for (i in c(1:length(l))) {
        load(paste('./data/Solution-', l[i], '.RData', sep=''))
        t1 = as.vector((solution$X[,2]+solution$X[,7]+solution$X[,8] )/solution$X[,1]) ##GGE = (gppTophy-phyToRes) / gppTOphy
        
        #HNF
        t2 = 1-(solution$X[,11]+solution$X[,12]+solution$X[,13] )/
            (solution$X[,3]+solution$X[,43]+solution$X[,48]+solution$X[,45])
        
        #MIC
        t3 = 1-(solution$X[,14]+solution$X[,17]+solution$X[,18])/
            (solution$X[,4] + solution$X[,9] +solution$X[,49] + solution$X[,44] + solution$X[,46])
        
        #SMZ
        t4 = 1-(solution$X[,21]+solution$X[,22]+solution$X[,23])/
            (solution$X[,5] + solution$X[,10] + solution$X[,15]+solution$X[,50] )
        
        #LMZ
        t5 = 1-(solution$X[,27] + solution$X[,28]+solution$X[,29]) / 
            (solution$X[,6] + solution$X[,19] + solution$X[,16] + solution$X[,51] + solution$X[,113])
        
        #dHNF
        t6 = 1- (solution$X[,60] + solution$X[,61] + solution$X[,62])/
            (solution$X[,93]  +solution$X[,95] + solution$X[,98])
        
        #dMIC
        t7 = 1- (solution$X[,65] + solution$X[,66] + solution$X[,67]) / 
            (solution$X[,94] + solution$X[,96] + solution$X[,99])
        
        #GEL
        t8 = 1- (solution$X[,30] + solution$X[,31] + solution$X[,32])/
            (solution$X[,24] +  solution$X[,120])
        
        #BAC
        t9 = 1- (solution$X[,42])/(solution$X[,53])
        
        #dBAC
        t10 = 1- (solution$X[,92])/(solution$X[,103])
        
        #vmSMZ
        t11 = 1- (solution$X[,116]+solution$X[,117]+solution$X[,119] + solution$X[,126])/
            (solution$X[,106]+solution$X[,108]+solution$X[,109]+solution$X[,110]+solution$X[,134]+solution$X[,135]+solution$X[,136])
        
        #vmLMZ
        t12 = 1- (solution$X[,123]+solution$X[,124]+solution$X[,125]+solution$X[,127]+solution$X[,57]+solution$X[,56])/
            (solution$X[,111]+solution$X[,112]+solution$X[,107]+solution$X[,114]+solution$X[,142]+solution$X[,118]+solution$X[,137]+solution$X[,138]+solution$X[,139])
        
        #dSMZ
        t13 = 1 - (solution$X[,70]+solution$X[,71]+solution$X[,72])/
            (solution$X[,64]+solution$X[,68]+solution$X[,100])
        
        #dLMZ
        t14 = 1 - (solution$X[,74]+solution$X[,75]+solution$X[,76])/
            (solution$X[,69]+solution$X[,73]+solution$X[,101]+solution$X[,130])
        
        GGE = data.frame(t2,t3,t4,t5,t6,t7,t8,t9,t10, t11, t12, t13, t14)[,w]
        names(GGE) = GGElab[w]
        GGEavg = apply(GGE, 2, mean)
        GGEsd = apply(GGE, 2, sd)
        
        k = sample(c(1:nrow(GGE)), 500)
        for (j in c(1:ncol(GGE))) {
            x = GGE[k ,j]
            
            points( 
                rep(j-0.4+0.8*i/length(l), length(x)), 
                x, 
                pch=14, 
                cex=0.2,
                col="#ff000005"
            )
        }
    }
    dev.off()
}