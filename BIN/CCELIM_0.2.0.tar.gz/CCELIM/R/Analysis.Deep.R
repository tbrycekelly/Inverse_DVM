#' Deep Analysis
#'
#' This script is designed analyze the set of runs <l> for aspects of the 2 layer ecosystem.
#' @param l A list of the data sets to analyze. For each plot, the data saved in the files specified by l will be loaded and plotted.
#' @param dir The prefered output directory for the generated images. Include the final '/' on linux/mac and '\' on windows.
#' @param hash The code used for the unique identification of the composite images. Default is CRC32 hash of l.
#' @import Matrix lattice ggplot2 RColorBrewer diagram digest
#' @export
#' @examples Analysis.Deep()
Analysis.Deep = function(l=NULL,
                         image.dir='~/temp/', 
                         hash=digest(runif(1),algo='crc32')
) {
    
    ######################## Individual Analyses ############################
    
    ######################## Group Analyses ############################
    
    #colors = c("#3030f0", "#2080a3", "#808080", "#b0b0b0", "#FF5050", "#e06060", "#4040f0", "#4580a3")
    colors = brewer.pal("Spectral", n=4)
    labels = c("POC", "Gel+MYC", "Meso", "Sub")
    
    ## Source of Carbon to Deep ##
    tempname = paste(image.dir, "Deep_Sources-", hash,".pdf",sep='')
    pdf(onefile=FALSE, tempname)
    
    smz = NULL
    gel = NULL
    poc = NULL
    sub = NULL
    
    for (i in c(1:length(l))) {
        load(paste("./data/Solution-", l[i], ".RData", sep=''))
        
        smz[i] = solution$avg[109] + solution$avg[106] + solution$avg[108] +
            solution$avg[110] + solution$avg[118] + solution$avg[107] + solution$avg[111] +
            solution$avg[112] - solution$avg[116] - solution$avg[117] - solution$avg[123] -
            solution$avg[124] - solution$avg[125] - solution$avg[122] - solution$avg[115] -
            solution$avg[120] - solution$avg[121] - solution$avg[119] - solution$avg[113]
        
        gel[i] = solution$avg[58] + solution$avg[59]
        poc[i] = solution$avg[54] + solution$avg[55]
        sub[i] = solution$avg[140] + solution$avg[141]
    }
    
    org.order = c(1, 4, 3, 2)
    export = rbind(poc, gel, smz, sub)[org.order,]
    
    par(mar=c(5,5,5,4))
    barplot(export, col=colors[org.order], main="Source of Carbon to Deep",
            ylim=c(0,800), density=NULL, xlab="Equation", ylab="Carbon Flux (mg C m^-2 d^-1)", xlim=c(0, length(l)+0.5))
    
    par(mar=c(3,3,3,4))
    legend(length(l)*0.8, 750, rev(labels[org.order]), lty=1, col=rev(colors[org.order]), lwd=3, cex=0.5)
    dev.off()
    
    #######################################
    
    #colors = c("#3030f0", "#2080a3", "#808080", "#b0b0b0", "#FF5050", "#e06060", "#4040f0", "#4580a3")
    colors = brewer.pal("Spectral", n=4)
    labels = c("POC", "Gel+MYC", "Meso", "Sub")
    
    ## Source of Carbon to Deep ##
    tempname = paste(image.dir, "Deep_SourcesRel-", hash,".pdf",sep='')
    pdf(onefile=FALSE, tempname)
    
    smz = NULL
    gel = NULL
    poc = NULL
    sub = NULL
    
    for (i in c(1:length(l))) {
        load(paste("./data/Solution-", l[i], ".RData", sep=''))
        
        smz[i] = solution$avg[109] + solution$avg[106] + solution$avg[108] +
            solution$avg[110] + solution$avg[118] + solution$avg[107] + solution$avg[111] +
            solution$avg[112] - solution$avg[116] - solution$avg[117] - solution$avg[123] -
            solution$avg[124] - solution$avg[125] - solution$avg[122] - solution$avg[115] -
            solution$avg[120] - solution$avg[121] - solution$avg[119] - solution$avg[113]
        
        gel[i] = solution$avg[58] + solution$avg[59]
        poc[i] = solution$avg[54] + solution$avg[55]
        sub[i] = solution$avg[140] + solution$avg[141]
    }
    
    
    par(mar=c(5,5,5,4))
    barplot(apply(export, 2, function(x) {x/sum(x)}), col=colors[org.order], main="Source of Carbon to Deep",
            ylim=c(0,1), density=NULL, xlab="Equation", ylab="Carbon Flux (mg C m^-2 d^-1)", xlim=c(0, length(l)+0.5))
    
    par(mar=c(3,3,3,4))
    legend(length(l)*0.8, 750, rev(labels[org.order]), lty=1, col=rev(colors[org.order]), lwd=3, cex=0.5)
    dev.off()
    
    
}