#' Indirect Analysis
#'
#' This script is designed analyze the set of runs <l> against ecosystem metrics.
#' @param l A list of the data sets to analyze. For each plot, the data saved in the files specified by l will be loaded and plotted.
#' @param dir The prefered output directory for the generated images. Include the final '/' on linux/mac and '\' on windows.
#' @param hash The code used for the unique identification of the composite images. Default is CRC32 hash of l.
#' @import Matrix lattice MASS
#' @export
#' @examples Analysis.Indirect()
#' 
Analysis.Indirect = function(l=NULL,
                             dir='./data/', 
                             image.dir='~/temp/', 
                             hash=digest(runif(1),algo='crc32'), 
                             Flow.Worksheet="./Input/End2End2LayerCompartments.xlsx", 
                             flow.count=31) {
    
    for ( index in 1:length(l) ) {
        ## Load seperate data
        load(paste(dir, 'Solution-', l[index], '.RData', sep=''))
        load(paste(dir, 'Model-', l[index], '.RData', sep=''))
        
        flow = ReadFlows(model, solution, Flow.Worksheet=Flow.Worksheet, flow.count = flow.count)
        
        #Normalize
        for (i in 1:length(flow[1,])) {
            flow[,i] = flow[,i]/sum(flow[,i])
        }
        flow[is.na(flow)] = 0
        
        indirect = ginv(diag( length(flow[,1]) ) - flow)   
        indirect[diag(length(indirect[,1])) == 1] = 0   ## Set diagonal to zero
        #indirect[flow > 0] = 0  ## Remove direct flows
        indirect[indirect < 1e-5] = 0
        write.csv(cbind(colnames(flow),indirect), paste0(dir, "Indirect-", l[index],".csv"))
        
        flow = ReadFlows(model, solution, Flow.Worksheet=Flow.Worksheet, flow.count = flow.count)
        
        #Normalize
        for (i in 1:length(flow[,1])) {
            flow[i,] = flow[i,]/sum(flow[i,])
        }
        flow[is.na(flow)] = 0
        
        indirect = ginv(diag( length(flow[,1]) ) - flow)   
        indirect[diag(length(indirect[,1])) == 1] = 0   ## Set diagonal to zero
        #indirect[flow > 0] = 0  ## Remove direct flows
        indirect[indirect < 1e-5] = 0
        write.csv(cbind(colnames(flow),indirect), paste0(dir, "IndirectUN-", l[index],".csv"))
        
        #indirectNC = apply(indirect, 2, function (x) x/max(x))
        #write.csv(cbind(colnames(flow),indirectNC), paste0(dir, "IndirectNC-", l[index],".csv"))
    }
    
}