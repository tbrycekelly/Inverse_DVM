#' plot.approximate.sd
#'
#' @import Matrix lattice ggplot2 RColorBrewer diagram digest
#' @importFrom XLConnect loadWorkbook saveWorkbook  writeWorksheet
#' @export
#' @examples plot.approximate.sd()
#' 
plot.approximate.sd = function(image.dir, hash, l) {
    
    tempname = paste(image.dir, "AppSD_Set_Rel-", hash, ".pdf", sep='')
    pdf(onefile=FALSE, tempname)
    par(mar=c(5,5,5,5), pin=c(6,4))
    
    load(paste("./data/Model-", l[1], ".RData", sep=''))
    num.approx = length(model$ba)
    
    ## Setup plotting area
    plot(NULL, pch=16, ylim=c(-8,8), xlim=c(1,num.approx),xaxt='n', ylab="SD in Measurement", main="SD away from Data", xlab='')
    
    if (length(model$ba) == 16) {
        ll = c("C14 PP", "Mic Gr", "SMZ Gr", "vmSMZ Gr", "LMZ Gr", "vmLMZ Gr", "ST Flux", "Thorium", "Bac Prod", "Myc Res", "dMyc Res", "Myc Fecal", "Myc Mort", "nvm Res", "nvm Fecal", "nvm Mort")
    }
    else {
        ll = c("C14 PP", "Mic Gr", "SMZ Gr", "vmSMZ Gr", "LMZ Gr", "vmLMZ Gr", "ST Flux", "Thorium", "Bac Prod", "Myc Res", "dMyc Res", "Myc Fecal", "Myc Mort", "nvm Res", "nvm Fecal", "nvm Mort", 'smz vm', 'lmz vm')
    }
    
    axis(side=1, 
         at=c(1:length(model$ba)), 
         las=2, 
         labels= ll
    )
    
    max = rep(0,length(model$ba))
    min = max
    
    for (i in c(1:length(l))) { # Loop for each run in l ####
        ## Load data
        load(paste("./data/Solution-", l[i], ".RData", sep=''))
        load(paste("./data/Model-", l[i], ".RData", sep=''))
        
        ## Calculate model b vectors and find mean and SD.
        Ra=NULL
        Ra$X = apply(solution$X, 1, function(x) model$Aa %*% x)
        Ra$avg = (apply(Ra$X, 1, mean)-model$ba)/model$sdb
        Ra$sd = apply(Ra$X, 1, sd)/model$sdb
        
        ### Plot results ####
        k = sample(c(1:ncol(Ra$X)), 500)
        for (j in 1:length(model$ba)) {
            points(j-0.5+0.7*i/length(l),y=Ra$avg[j], pch=16, xlab="")
            points(rep(j-0.5+0.7*i/length(l), length(k)), (Ra$X[j,k]-model$ba[j]) / model$sdb[j],
                   col="#00000022", pch=16, cex=0.16)
            if (abs(Ra$avg[j]) > 3) {
                text(j-0.5+0.7*(i+4)/length(l), y=Ra$avg[j], i, cex=0.75)
            }
        }
    }
    
    ### Draw solution bounding boxes ####
    for (i in 1:length(model$ba)) {
        lines(c(-0.5+i,-0.5+i, 0.45+i,0.45+i,-0.5+i),c(min[i],max[i],max[i],min[i],min[i]), col="#ff000060")
    }
    
    #### Draw horizontal lines at +-2 SD and 0 ####
    lines(c(0,num.approx+1),c(0,0), lty=3)
    lines(c(0,num.approx+1),c(2,2), lty=3, col='#ff000080')
    lines(c(0,num.approx+1),c(-2,-2), lty=3, col='#ff000080')
    dev.off()

}
