#' Approimate Analysis
#'
#' This script is designed analyze the set of runs <l> against the approimate equations of the model.
#' @param l A list of the data sets to analyze. For each plot, the data saved in the files specified by l will be loaded from <./data/Model-...> and plotted.
#' @param image.dir The prefered output directory for the generated images. Include the final '/' on linux/mac and '\' on windows.
#' @param hash The code used for the unique identification of the composite images. Default is CRC32 hash of l.
#' @import Matrix lattice ggplot2 RColorBrewer diagram digest
#' @importFrom XLConnect loadWorkbook saveWorkbook writeWorksheet
#' @export
#' @examples Analysis.Approximate('Test01')
#' 
Analysis.Approximate = function(l=NULL, 
                                image.dir='~/temp/', 
                                hash=digest(runif(1),algo='crc32')) {
    
    #########################################################################
    ################### SDs from measured value.############################
    #########################################################################
    image.dir = image.dir
    hash = hash
    
    plot.approximate.sd(image.dir= image.dir, hash = hash, l)
    plot.approximate.abs(image.dir = image.dir, hash= hash, l)
}
