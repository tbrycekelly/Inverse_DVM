#' Ecosystem Analysis
#'
#' This script is designed analyze the set of runs <l> against ecosystem metrics.
#' @param l A list of the data sets to analyze. For each plot, the data saved in the files specified by l will be loaded and plotted.
#' @param dir The prefered output directory for the generated images. Include the final '/' on linux/mac and '\' on windows.
#' @param hash The code used for the unique identification of the composite images. Default is CRC32 hash of l.
#' @import Matrix lattice ggplot2 RColorBrewer diagram
#' @export
#' @examples Analysis.Ecosystem()
#' 
Analysis.Ecosystem = function(l=NULL, 
                              image.dir='~/temp/', 
                              hash=digest(runif(1),algo='crc32'), 
                              Flow.Worksheet="./Input/End2End2LayerCompartments.xlsx", 
                              flow.count=31
                              ) {
    
    
    # GGElab = c("Hnf", "Mic", "Smz", "Lmz", "Deep Hnf", "Deep Mic", "Gel", "Bac", "Deep Bac", "vmSMZ", "vmLMZ", "dSMZ", "dLMZ")
    
    try( plot.gge(image.dir, paste0('All_', hash), l, c(1:13)) )
    try( plot.gge(image.dir, paste0('Meso_', hash), l, c(3, 4, 10:13)) )
    
    
    
    
    #tempname = paste(image.dir, "Ecosystem_Path-", hash, ".pdf", sep='')
    tempname = paste(image.dir, "Ecosystem_Path-", hash, ".png", sep='')
    png(tempname)
    #pdf(onefile=FALSE, tempname)
    foodchain = FALSE
    
    for (i in 1:length(l)) {
        load(paste("../Inverse/Data/Solution-", l[i], ".RData", sep=''))
        load(paste("../Inverse/Data/Model-", l[i], ".RData", sep=''))
        
        gpp = solution$X[,1] - solution$X[,2] - solution$X[,8]
        herb = (solution$X[,5] + solution$X[,6] + solution$X[,106] + solution$X[,107])/gpp
        mult = (solution$X[,3] + solution$X[,4])/gpp
        ml = solution$X[,53] / gpp
         if (foodchain[1] == FALSE) {
             foodchain = cbind(herb, mult, ml)
         } else {
             foodchain = cbind(foodchain, herb, mult, ml)
         }
    }
    
    boxplot(foodchain, outline=FALSE, col = c("green", 'orange', 'grey', 'white'), xaxt='n', xlab='Cycle', ylab='Rel. Strength')
    legend(20, 1.7, c("Herbiverous", "Multivorous", "Microbial Loop"), col=c('green', 'orange', 'grey'), lwd=6)
    
    ## Draw lines between each cycle
    for (i in 1:9) {
        lines(c(4*i,4*i), c(-1,2), lty=2, col='#000000a0')
    }
    ## Label each cycle 1:9
    axis(1, at = 4*c(1:9)-2, labels = c(1:9))
    
    dev.off()
}