#' Grazing Analysis
#'
#' This script is designed analyze the set of runs <l> against the approximate equations of the model.
#' @param l A list of the data sets to analyze. For each plot, the data saved in the files specified by l will be loaded and plotted.
#' @param dir The prefered output directory for the generated images. Include the final '/' on linux/mac and '\' on windows.
#' @param hash The code used for the unique identification of the composite images. Default is CRC32 hash of l.
#' @import Matrix lattice RColorBrewer diagram digest
#' @export
#' @examples Analysis.Grazing(<l>)
Analysis.Grazing = function(l=NULL, 
                            image.dir='~/temp/', 
                            hash=digest(runif(1),algo='crc32')
                            ) {

    ######################## Individual Analyses ############################

   for (i in 1:4) {
       plot.graz(image.dir, hash, l, i)
   }
}
