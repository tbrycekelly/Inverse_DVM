plot.graz = function(image.dir, hash, l, n) {
    
    tempname = paste(image.dir, 'Graz_', n, '_', hash,".pdf",sep='')
    pdf(onefile=FALSE, tempname)
    par(mar=c(5.1, 7.1, 4.1, 2.1))
    
    labels=c("C14 PP", "Mic Gr", "SMZ Gr", "vmSMZ Gr", "LMZ Gr", "vmLMZ Gr", "ST Flux", "Thorium", "Bac Prod", "Myc Res", "dMyc Res", "Myc Fecal", "Myc Mort", "nvm Res", "nvm Fecal", "nvm Mort")
    
    ## Determine the axis limits
    max = 0
    min = 0
    for (i in 1:length(l)) {
        load(paste("./data/Solution-", l[i], ".RData", sep=''))
        load(paste("./data/Model-", l[i], ".RData", sep=''))
        
        temp = model$ba[n] + model$sdb[n]
        if (max < temp) max = temp
        temp = model$ba[n] - model$sdb[n]
        if (min > temp) min = temp
        temp = (model$Aa %*% solution$avg + model$Aa %*% solution$sd)[n]
        if (max < temp) max = temp
        temp = (model$Aa %*% solution$avg - model$Aa %*% solution$sd)[n]
        if (min > temp) min = temp
    }
    min = 1.1*min
    max = 1.1*max
    
    plot(x=c(min:max), y=c(min:max), type='l',lty=2 , pch=16, ylim=c(min,max),xlim = c(min,max),cex.lab=1.4,
         ylab=expression(Model~Carbon~Flux~(mg~C~m^{-2}~d^{-1})),
         xlab=expression(Measured~Carbon~Flux~(mg~C~m^{-2}~d^{-1})),
         main=labels[n])
    
    for (i in c(1:length(l))) {
        load(paste("./data/Solution-", l[i], ".RData", sep=''))
        load(paste("./data/Model-", l[i], ".RData", sep=''))
        RX = model$Aa %*% solution$avg
        RS = model$Aa %*% solution$sd
        points(model$ba[n], RX[n])
        text(min, RX[n], labels = i, cex = 0.75)
        text(model$ba[n], min, labels = i, cex = 0.75)
        segments(model$ba[n]+model$sdb[n], RX[n], model$ba[n]-model$sdb[n], RX[n])
        segments(model$ba[n]+model$sdb[n], RX[n]*0.98, model$ba[n]+model$sdb[n], RX[n]*1.02)
        segments(model$ba[n]-model$sdb[n], RX[n]*0.98, model$ba[n]-model$sdb[n], RX[n]*1.02)
        segments(model$ba[n], RX[n]+RS[n], model$ba[n], RX[n]-RS[n], col="red")
        segments(model$ba[n]*0.98, RX[n]+RS[n], model$ba[n]*1.02, RX[n]+RS[n], col="red")
        segments(model$ba[n]*0.98, RX[n]-RS[n], model$ba[n]*1.02, RX[n]-RS[n], col="red")
    }
    dev.off()
}