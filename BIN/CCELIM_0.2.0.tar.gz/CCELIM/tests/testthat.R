library(testthat)
library(CCELIM)

test_check("CCELIM")
