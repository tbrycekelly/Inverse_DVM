context("Initial Conditions")

test_that("The default values are returned", expect_error(MCMC.Sample()))
